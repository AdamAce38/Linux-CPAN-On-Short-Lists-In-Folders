package Astro::Catalog::Star::Morphology;

use Astro::Catalog::Item::Morphology;

use base qw / Astro::Catalog::Item::Morphology /;
use vars qw/ $VERSION /;
'$Revision: 1.4 $ ' =~ /.*:\s(.*)\s\$/ && ($VERSION = $1);

=head1 NAME

Astro::Catalog::Star::Morphology

=head1 DESCRIPTION

This class is present for backwards compatibility only.

=head1 SEE OTHER

See C<Astro::Catalog::Item::Morphology>.

=cut

1;
