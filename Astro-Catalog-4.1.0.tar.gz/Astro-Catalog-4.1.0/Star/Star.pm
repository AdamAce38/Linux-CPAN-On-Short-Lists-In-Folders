package Astro::Catalog::Star;

use Astro::Catalog::Item;

use base qw/ Astro::Catalog::Item /;
use vars qw/ $VERSION /;
'$Revision: 1.25 $ ' =~ /.*:\s(.*)\s\$/ && ($VERSION = $1);

=head1 NAME

Astro::Catalog::Star

=head1 DESCRIPTION

This class is present for backwards compatibility only.

=head1 SEE OTHER

See C<Astro::Catalog::Item>.

=cut

1;
